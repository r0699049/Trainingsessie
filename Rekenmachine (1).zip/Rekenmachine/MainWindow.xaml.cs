﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Rekenmachine
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Label currentNumberLabel, resultLabel;

        private string currentNumber="";
        private double result=0;
        private double number1=0,number2=0;
        private string task;

        public MainWindow()
        {
            InitializeComponent();
            currentNumberLabel = (Label)this.FindName("labelCurrentNumber");
            resultLabel = (Label)this.FindName("labelResult");
        }

        private void Button_0(object sender, RoutedEventArgs e)
        {
            currentNumber += "0";
            UpdateLabel(currentNumber);
        }

        private void Button_1(object sender, RoutedEventArgs e)
        {
            currentNumber += "1";
            UpdateLabel(currentNumber);
        }

        private void Button_2(object sender, RoutedEventArgs e)
        {
            currentNumber += "2";
            UpdateLabel(currentNumber);
        }

        private void Button_3(object sender, RoutedEventArgs e)
        {
            currentNumber += "3";
            UpdateLabel(currentNumber);
        }

        private void Button_4(object sender, RoutedEventArgs e)
        {
            currentNumber += "4";
            UpdateLabel(currentNumber);
        }

        private void Button_5(object sender, RoutedEventArgs e)
        {
            currentNumber += "5";
            UpdateLabel(currentNumber);
        }

        private void Button_6(object sender, RoutedEventArgs e)
        {
            currentNumber += "6";
            UpdateLabel(currentNumber);
        }

        private void Button_7(object sender, RoutedEventArgs e)
        {
            currentNumber += "7";
            UpdateLabel(currentNumber);
        }

        private void Button_8(object sender, RoutedEventArgs e)
        {
            currentNumber += "8";
            UpdateLabel(currentNumber);
        }

        private void Button_9(object sender, RoutedEventArgs e)
        {
            currentNumber += "9";
            UpdateLabel(currentNumber);
        }

        private void Button_dot(object sender, RoutedEventArgs e)
        {
            currentNumber += ",";
            UpdateLabel(currentNumber);
        }

        private void Button_multiply(object sender, RoutedEventArgs e)
        {
            task = "*";
            ChangeNumber();
        }

        private void Button_divide(object sender, RoutedEventArgs e)
        {
            task = "/";
            ChangeNumber();
        }

        private void Button_minus(object sender, RoutedEventArgs e)
        {
            task = "-";
            ChangeNumber();
        }

        private void Button_plus(object sender, RoutedEventArgs e)
        {
            task = "+";
            ChangeNumber();
        }

        private void Button_result(object sender, RoutedEventArgs e)
        {
            Calculate();
        }

        private void ChangeNumber()
        {
                number1 = Convert.ToDouble(currentNumber);
                currentNumber = "";

                labelResult.Content = number1.ToString();
                labelCurrentNumber.Content = "0";
        }

        private void UpdateLabel(string text)
        {
            currentNumberLabel.Content = text.ToString();
        }

        private void Calculate()
        {

            number2 = Convert.ToDouble(currentNumber);
            currentNumber = "0";
            currentNumberLabel.Content = currentNumber;

            switch (task)
            {
                case "-":
                    result = number1 - number2;
                    break;
                case "+":
                    result = number1 + number2;
                    break;
                case "/":
                    result = number1 / number2;
                    break;
                case "*":
                    result = number1*number2;
                    break;
                case "=":

                    break;
            }

            labelCurrentNumber.Content = result.ToString();
            labelResult.Content = "0";

        }


    }
}
